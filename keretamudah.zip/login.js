document.getElementById('loginButton').addEventListener('click', function() {
    document.getElementById('loginContainer').style.display = 'block';
});